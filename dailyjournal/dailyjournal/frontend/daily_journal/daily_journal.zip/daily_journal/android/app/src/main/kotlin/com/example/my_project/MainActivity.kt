package com.diviso.dailyjournal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
