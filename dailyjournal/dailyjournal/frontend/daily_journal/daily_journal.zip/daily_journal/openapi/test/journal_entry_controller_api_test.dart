import 'package:test/test.dart';
import 'package:openapi/openapi.dart';


/// tests for JournalEntryControllerApi
void main() {
  final instance = Openapi().getJournalEntryControllerApi();

  group(JournalEntryControllerApi, () {
    //Future<JournalEntry> createJournalEntry(JournalEntry journalEntry) async
    test('test createJournalEntry', () async {
      // TODO
    });

    //Future deleteJournalEntry(int id) async
    test('test deleteJournalEntry', () async {
      // TODO
    });

    //Future<BuiltList<JournalEntry>> getAllJournalEntries() async
    test('test getAllJournalEntries', () async {
      // TODO
    });

    //Future<JournalEntry> getJournalEntryById(int id) async
    test('test getJournalEntryById', () async {
      // TODO
    });

    //Future<JournalEntry> updateJournalEntry(int id, JournalEntry journalEntry) async
    test('test updateJournalEntry', () async {
      // TODO
    });

  });
}
