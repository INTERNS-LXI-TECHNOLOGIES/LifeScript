package com.lxisoft.voiceAssist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoiceAssistApplicationTests {

	@Test
	void contextLoads() {
	}

}
