package com.lxisoft.voiceAssist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VoiceAssistApplication {

	public static void main(String[] args) {
		SpringApplication.run(VoiceAssistApplication.class, args);
	}

}
